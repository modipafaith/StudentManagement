import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;

public class StudentService {

    private final ArrayList<Student> students = new ArrayList<>();

    // VALIDATE ID NUMBER
    public boolean isValidIdNumber(String idNumber) {
        return idNumber != null && idNumber.matches("\\d{13}");
    }

    // CALCULATE AGE FROM ID
    public int calculateAgeFromId(String idNumber) {
        int year = Integer.parseInt(idNumber.substring(0, 2));
        int month = Integer.parseInt(idNumber.substring(2, 4));
        int day = Integer.parseInt(idNumber.substring(4, 6));

        int currentYear = LocalDate.now().getYear() % 100;

        // Determine century (1900s or 2000s)
        int fullYear = (year <= currentYear) ? 2000 + year : 1900 + year;

        LocalDate birthDate = LocalDate.of(fullYear, month, day);
        return Period.between(birthDate, LocalDate.now()).getYears();
    }

    // ADDING STUDENT
    public void addStudent(String idNumber, String name, String surname, String gender, String address, String race) {

        if (!isValidIdNumber(idNumber)) {
            System.out.println("Invalid ID number. Must be exactly 13 digits.");
            return;
        }

        if (findStudent(idNumber) != null) {
            System.out.println("Student with this ID already exists.");
            return;
        }

        int age = calculateAgeFromId(idNumber);
        Student student = new Student(idNumber, name, surname, age, gender, address, race);
        students.add(student);

        System.out.println("Student added successfully. Age calculated automatically.");
    }

    // VIEWING STUDENT INFO AS TABLE
public void viewStudents() {
    if (students.isEmpty()) {
        System.out.println("No students found.");
        return;
    }

    // Print table header
    System.out.printf("%-15s %-12s %-12s %-5s %-8s %-20s %-10s%n",
            "ID Number", "Name", "Surname", "Age", "Gender", "Address", "Race");
    System.out.println("--------------------------------------------------------------------------------------");

    // Print each student
    for (Student s : students) {
        System.out.printf("%-15s %-12s %-12s %-5d %-8s %-20s %-10s%n",
                s.getIdNumber(),
                s.getName(),
                s.getSurname(),
                s.getAge(),
                s.getGender(),
                s.getAddress(),
                s.getRace());
    }
}


    // FINDING STUDENT
    public Student findStudent(String idNumber) {
        for (Student s : students) {
            if (s.getIdNumber().equals(idNumber)) {
                return s;
            }
        }
        return null;
    }

    // UPDATING STUDENT INFO
    public void updateStudent(String idNumber, String newName, String newSurname, String newGender, String newAddress, String newRace) {

        Student s = findStudent(idNumber);

        if (s != null) {
            s.setName(newName);
            s.setSurname(newSurname);
            s.setGender(newGender);
            s.setAddress(newAddress);
            s.setRace(newRace);
            System.out.println("Student updated successfully.");
        } else {
            System.out.println("Student not found.");
        }
    }

    // DELETING STUDENT
    public void deleteStudent(String idNumber) {
        Student s = findStudent(idNumber);

        if (s != null) {
            students.remove(s);
            System.out.println("Student deleted successfully.");
        } else {
            System.out.println("Student not found.");
        }
    }
}
