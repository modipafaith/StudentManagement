import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        StudentService service = new StudentService();
        try (Scanner scanner = new Scanner(System.in)) {
            boolean running = true;

            while (running) {

                System.out.println("\n--- Student Management System ---");
                System.out.println("1. Add Student");
                System.out.println("2. View Students");
                System.out.println("3. Find Student");
                System.out.println("4. Update Student");
                System.out.println("5. Delete Student");
                System.out.println("6. Exit");
                System.out.print("Choose an option: ");

                int choice = scanner.nextInt();
                scanner.nextLine(); // clear buffer

                switch (choice) {

                    case 1 -> {
                        System.out.print("Enter 13-digit ID number: ");
                        String idNumber = scanner.nextLine();

                        System.out.print("Enter Name: ");
                        String name = scanner.nextLine();

                        System.out.print("Enter Surname: ");
                        String surname = scanner.nextLine();

                        System.out.print("Enter Gender: ");
                        String gender = scanner.nextLine();

                        System.out.print("Enter Address: ");
                        String address = scanner.nextLine();

                        System.out.print("Enter Race: ");
                        String race = scanner.nextLine();

                        service.addStudent(idNumber, name, surname, gender, address, race);
                    }

                    case 2 -> service.viewStudents();

                    case 3 -> {
                        System.out.print("Enter ID number to search: ");
                        String searchId = scanner.nextLine();

                        Student found = service.findStudent(searchId);
                        if (found != null) {
                            System.out.println(found);
                        } else {
                            System.out.println("Student not found.");
                        }
                    }

                    case 4 -> {
                        System.out.print("Enter ID number to update: ");
                        String updateId = scanner.nextLine();

                        System.out.print("Enter new Name: ");
                        String newName = scanner.nextLine();

                        System.out.print("Enter new Surname: ");
                        String newSurname = scanner.nextLine();

                        System.out.print("Enter new Gender: ");
                        String newGender = scanner.nextLine();

                        System.out.print("Enter new Address: ");
                        String newAddress = scanner.nextLine();

                        System.out.print("Enter new Race: ");
                        String newRace = scanner.nextLine();

                        service.updateStudent(updateId, newName, newSurname, newGender, newAddress, newRace);
                    }

                    case 5 -> {
                        System.out.print("Enter ID number to delete: ");
                        String deleteId = scanner.nextLine();

                        service.deleteStudent(deleteId);
                    }

                    case 6 -> {
                        running = false;
                        System.out.println("Goodbye 👋");
                    }

                    default -> System.out.println("Invalid option.");
                }
            }
        }
    }
}
