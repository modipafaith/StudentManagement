public class Student {
    private final String idNumber;
    private String name;
    private String surname;
    private int age;
    private String gender;
    private String address;
    private String race;

    // Constructor
    public Student(String idNumber, String name, String surname, int age, String gender, String address, String race) {
        this.idNumber = idNumber;
        this.name = name;
        this.surname = surname;
        this.age = age;
        this.gender = gender;
        this.address = address;
        this.race = race;
    }

    // Getters
    public String getIdNumber() {
        return idNumber;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    public String getAddress() {
        return address;
    }

    public String getRace() {
        return race;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setRace(String race) {
        this.race = race;
    }

    // toString method
    @Override
    public String toString() {
        return "ID Number: " + idNumber
                + ", Name: " + name
                + ", Surname: " + surname
                + ", Age: " + age
                + ", Gender: " + gender
                + ", Address: " + address
                + ", Race: " + race;
    }
}
